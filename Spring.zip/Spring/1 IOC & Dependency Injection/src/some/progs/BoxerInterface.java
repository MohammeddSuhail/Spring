package some.progs;

public interface BoxerInterface {
	public String boxingDetails();
}
