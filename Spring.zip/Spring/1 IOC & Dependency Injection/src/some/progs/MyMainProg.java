package some.progs;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyMainProg {

	public static void main(String[] args) {
		
		//load spring configuration file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		//retrieve bean(class) from spring container
		//this uses constructor injection, check config file
		CoachInterface coach1 = context.getBean("myCoach", CoachInterface.class);
		
		//call methods, basically use it
		coach1.getDetails();
		
		System.out.println(coach1.boxingDetails());
		
		
		
		//retrieve bean(class) from spring container
		//it uses setter injection, check config file
		JumppingAndOtherCoachWithSetterInjection coach2 = context.getBean("otherCoach", JumppingAndOtherCoachWithSetterInjection.class);
		coach2.getDetails();
		System.out.println(coach2.boxingDetails());
		System.out.println("Rank: " + coach2.getRank());
		System.out.println("Location: " + coach2.getLoc());
		
		//close the context
		context.close();

	}

}
