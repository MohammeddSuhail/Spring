package some.progs;

public class BoxerCoach implements BoxerInterface{

	@Override
	public String boxingDetails() {
		return "Wake up and box for 1 hour each day";
	}

}
