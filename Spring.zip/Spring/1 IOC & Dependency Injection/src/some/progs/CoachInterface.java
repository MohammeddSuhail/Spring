package some.progs;

public interface CoachInterface {
	public void getDetails();
	public String boxingDetails();
}
