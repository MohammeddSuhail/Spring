package some.progs;

public class JumppingAndOtherCoach implements CoachInterface{
	
	String noOfJumps;
	
	BoxerInterface boxerInterface;
	
	//Constructor injection: we needed object of BoxerCoach in here, 
	//so we used constructor injection to get the object
	//                       or (BoxerInterface boxer)
	public JumppingAndOtherCoach(BoxerCoach boxer) {
		boxerInterface = boxer;
	}
	

	@Override
	public void getDetails() {
		System.out.println("Jump daily");
	}

	@Override
	public String boxingDetails() {
		return boxerInterface.boxingDetails();
	}

}
