package some.progs;

public class JumppingAndOtherCoachWithSetterInjection implements CoachInterface{
	
	int rank;
	String loc;
	

	BoxerInterface boxerInterface;
	
	//Setter injection: we needed object of BoxerCoach in here, 
	//so we used constructor injection to get the object
	//                       or (BoxerInterface boxer)
	public void setBoxerInterface(BoxerInterface boxerInterface) {
		this.boxerInterface = boxerInterface;
	}
	

	@Override
	public void getDetails() {
		System.out.println("Jump daily from coach2");
	}

	@Override
	public String boxingDetails() {
		return boxerInterface.boxingDetails() + " from coach2";
	}
	
	
	
	public int getRank() {
		return rank;
	}


	public void setRank(int rank) {
		this.rank = rank;
	}


	public String getLoc() {
		return loc;
	}


	public void setLoc(String loc) {
		this.loc = loc;
	}

}
