package spring_project_annotations;

import org.springframework.stereotype.Component;

@Component
public class JumppingCoach2 implements CoachInterface {

	@Override
	public String getDetails() {
		return "coach2: Jump harder";
	}
}
