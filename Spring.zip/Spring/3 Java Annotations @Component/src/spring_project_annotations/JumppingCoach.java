package spring_project_annotations;

import org.springframework.stereotype.Component;

@Component("jumpId")
public class JumppingCoach implements CoachInterface {

	@Override
	public String getDetails() {
		return "Jump jump jump";
	}
}
