package spring_project_annotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainProg {

	public static void main(String[] args) {
		
		//load spring configuration file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				
		//retrieve bean(class) from spring container
		//here we gave id to the bean
		CoachInterface coach1 = context.getBean("jumpId", CoachInterface.class);
				
		//call methods, basically use it
		System.out.println(coach1.getDetails());
		
		
		//retrieve bean(class) from spring container
		//here it is default bean name 
		//if bean name: JumppingCoach2
		//then default id: jumppingCoach2
		CoachInterface coach2 = context.getBean("jumppingCoach2", CoachInterface.class);
		System.out.println(coach2.getDetails());		
		
		//close the context
		context.close();

	}

}
