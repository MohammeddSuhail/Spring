package spring_project_annotations;

public interface CoachInterface {
	public String getDetails(); 
}
