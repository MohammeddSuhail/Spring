package spring_config_using_java_code_with_no_compo_scan_using_bean_annotation;

public interface CoachInterface {
	public String getDetails(); 
}
