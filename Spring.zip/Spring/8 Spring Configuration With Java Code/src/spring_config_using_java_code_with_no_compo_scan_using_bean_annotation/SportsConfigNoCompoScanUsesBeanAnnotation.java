package spring_config_using_java_code_with_no_compo_scan_using_bean_annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


//Without using component scan(no @Component above bean and no autowiring), 
//still we can work with spring by defining the bean inside the jav config file by using @Bean annotation



//ComponentScan not used, instead @Bean with corresponding func is used
@Configuration      //makes this file as config file: it tells, follow this configuration file
public class SportsConfigNoCompoScanUsesBeanAnnotation {
	
	@Bean   //defines the existence of the below bean and by default the scope is singleton
	public BoxerCoach boxerCoach() {   //bean id will be the function name specified here
		return new BoxerCoach();
	}
	
	@Bean
	public JumppingCoach jumppingCoach() {
		return new JumppingCoach(boxerCoach());
	}
}
