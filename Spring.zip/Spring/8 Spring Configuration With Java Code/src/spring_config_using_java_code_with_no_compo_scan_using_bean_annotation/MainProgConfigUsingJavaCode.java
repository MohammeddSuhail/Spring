package spring_config_using_java_code_with_no_compo_scan_using_bean_annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainProgConfigUsingJavaCode {

	public static void main(String[] args) {
		
		
		System.out.println("\nComponentScan not used, instead @Bean with corresponding func is used");
		
		//read spring config java class, here we used java class as config file
		AnnotationConfigApplicationContext context2 = new AnnotationConfigApplicationContext(SportsConfigNoCompoScanUsesBeanAnnotation.class);
		
		//get the bean from spring container
		CoachInterface coach2 = context2.getBean("jumppingCoach",JumppingCoach.class);
		
		//use the bean
		System.out.println(coach2.getDetails());
		
		//close context
		context2.close();		
		
		
	}

}
