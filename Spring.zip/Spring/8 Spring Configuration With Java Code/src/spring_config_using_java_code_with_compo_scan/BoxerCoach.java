package spring_config_using_java_code_with_compo_scan;

import org.springframework.stereotype.Component;

@Component
public class BoxerCoach implements BoxerInterface{

	@Override
	public String boxingDetails() {
		return "Wake up and box for 1 hour each day";
	}

}
