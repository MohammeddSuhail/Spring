package spring_config_using_java_code_with_compo_scan;

public interface BoxerInterface {
	public String boxingDetails();
}
