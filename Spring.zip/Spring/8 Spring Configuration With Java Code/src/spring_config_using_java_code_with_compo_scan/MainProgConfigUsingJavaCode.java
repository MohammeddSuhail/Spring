package spring_config_using_java_code_with_compo_scan;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainProgConfigUsingJavaCode {

	public static void main(String[] args) {
		
		System.out.println("Component Scan is used");
		
		//read spring config java class, here we used java class as config file
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SportsConfigUsesCompoScan.class);
		
		//get the bean from spring container
		CoachInterface coach = context.getBean("jumppingCoach",JumppingCoach.class);
		
		//use the bean
		System.out.println(coach.getDetails());
		
		//close context
		context.close();
		
	}

}
