package spring_config_using_java_code_with_compo_scan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JumppingCoach implements CoachInterface {
	
	BoxerInterface boxerInterface;

	//For Constructor injection
	//the @Autowired will basically search for bean and create it
	@Autowired
	public JumppingCoach(BoxerInterface boxerInterface) {
		this.boxerInterface = boxerInterface;
	}
	
	public String getBoxDetails() {
		return boxerInterface.boxingDetails();
	}
	

	@Override
	public String getDetails() {
		return "Jump jump jump";
	}
}

