package spring_config_using_java_code_with_compo_scan;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration      //makes this file as config file: it tells, follow this configuration file
@ComponentScan("spring_config_using_java_code_with_compo_scan")  //tells spring scan this package for beans(class with @Component above it)
public class SportsConfigUsesCompoScan {
	
}
