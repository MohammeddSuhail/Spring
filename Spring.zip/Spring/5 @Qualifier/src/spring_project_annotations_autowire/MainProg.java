package spring_project_annotations_autowire;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainProg {

	public static void main(String[] args) {
		
		//load spring configuration file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				
		
		//Autowiring: @Qualifier with Field Injection 
		System.out.println("\nUses Qualifier Annotation to be specify which bean to use when mutiple implementaton of interface is there");
		JumppingCoach5UsesQualifierAnnotation coach5 = context.getBean("jumppingCoach5UsesQualifierAnnotation", JumppingCoach5UsesQualifierAnnotation.class);
		System.out.println(coach5.getDetails());
		System.out.println(coach5.getBoxDetails());
		
		
		//close the context
		context.close();

	}

}
