package com.mvcdemo;

import java.util.LinkedHashMap;

public class Student {
	
	String firstName, lastName, country, year, favouriteLanguage;
	
	LinkedHashMap<String,String> options;
	
	String[] operatingSystems;
	


	public Student() {
		//list for populating drop down
		options = new LinkedHashMap<String, String>();
		options.put("1","one");
		options.put("2","two");
		options.put("3","three");
		options.put("4","four");
	}
	
	
	public void setOperatingSystems(String[] operatingSystems) {
		this.operatingSystems = operatingSystems;
	}
	
	public String[] getOperatingSystems() {
		return operatingSystems;
	}

	
	

	public String getYear() {
		return year;
	}

	public String getFavouriteLanguage() {
		return favouriteLanguage;
	}

	public void setFavouriteLanguage(String favouriteLanguage) {
		this.favouriteLanguage = favouriteLanguage;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public LinkedHashMap<String, String> getOptions() {
		return options;
	}

	public void setOptions(LinkedHashMap<String, String> options) {
		this.options = options;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	

}
