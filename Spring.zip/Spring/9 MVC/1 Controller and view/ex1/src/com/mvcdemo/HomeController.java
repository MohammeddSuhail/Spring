package com.mvcdemo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller    //@Controller extends @Component
public class HomeController {
                      //mapping method to web request
	@RequestMapping   //@RequestMapping("reqname"), if just @RequestMapping , then it's base page
	public String showPage() {
		return "main-page";  //page that needs to be displayed , WEB-INF/view/main-page.jsp will added because of infix and postfix specifies in .xml file
	}
}
