package com.mvcdemo;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Customer {
	String firstName;
	
	@NotNull(message="this field can't be null")
	@Size(min=1, message="length must be >=1")
	String lastName;
	
	
	@Min(value=0, message="must be >= 0")
	@Max(value=100, message="must be <= 100")
	Integer freePass;   //if no input is given, it takes as null, but int can;t have null so we use Integer
	
	
	@Pattern(regexp="^[a-zA-Z0-9]{10}", message="Must be of 10 chracters")
	String USN;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getFreePass() {
		return freePass;
	}

	public void setFreePass(Integer freePass) {
		this.freePass = freePass;
	}

	public String getUSN() {
		return USN;
	}

	public void setUSN(String uSN) {
		USN = uSN;
	}
	
	
}
