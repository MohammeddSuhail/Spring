package com.mvcdemo;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	
	
	@InitBinder      //it pre-processes each request to the controller
	public void initBinder(WebDataBinder dataBinder) {
		//below line performs trim operation,                           true means trim to null
		StringTrimmerEditor stringTrimmerEditor = new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class, stringTrimmerEditor);
	}
	
	

	@RequestMapping("/showForm")
	public String showForm(Model model) {
		
		model.addAttribute("customer", new Customer());
		
		return "customer-form-validators";
	}
	
	@RequestMapping("/processForm")
	public String processForm(@Valid @ModelAttribute("customer") Customer customer, BindingResult bindingResult) {
		//@Valid: performs validation rules on Customer Object
		//BindingResult: will have result of the validation
		
		System.out.println("Result of validation: " + bindingResult);
		
		if(bindingResult.hasErrors()) {   //checking if any error
			return "customer-form-validators";
		}else {
			return "customer-response";
		}
	}
}
