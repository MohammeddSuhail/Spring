package com.mvcdemo;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloWorldController {

	@RequestMapping("showForm")
	public String showForm() {
		return "hello-form";
	}
	
	
	@RequestMapping("processForm")
	public String processForm() {
		return "helloworld";
	}
	
	
	@RequestMapping("processFormVersionTwo")
	public String letsSoutDude(HttpServletRequest request, Model model) { //HttpServletRequest has form data
		                                                                  //we can store anything in model
		//read the request parameter from html the form
		String theName = request.getParameter("studentName");
		
		theName.toUpperCase();
		
		//create message
		theName = "Yo! " + theName;
		
		//add to model
		model.addAttribute("message", theName);
		
		
		return "helloworld";
	}
	
	
	
	@RequestMapping("processFormVersionThree")
	public String processFormVersionThree( @RequestParam("studentName") String theName, Model model) { 
		
		theName.toUpperCase();
		
		//create message
		theName = "Hello from v3 " + theName;
		
		//add to model
		model.addAttribute("message", theName);
		
		
		return "helloworld";
	}
}
