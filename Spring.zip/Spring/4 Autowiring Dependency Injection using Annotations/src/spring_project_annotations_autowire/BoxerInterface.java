package spring_project_annotations_autowire;

public interface BoxerInterface {
	public String boxingDetails();
}
