package spring_project_annotations_autowire;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class JumppingCoach5UsesQualifierAnnotation implements CoachInterface {
	
	//For Field injection:
	//no need of using any method for setting the bean
	//the @Autowired will basically search for bean and create it
	@Autowired
	@Qualifier("boxerCoach")        //for specifying bean to use
	BoxerInterface boxerInterface;
	
	@Override
	public String getDetails() {
		return "coach2: Jump harder";
	}
	
	public BoxerInterface getBoxerInterface() {
		return boxerInterface;
	}
	
	public String getBoxDetails() {
		return boxerInterface.boxingDetails();
	}

}
