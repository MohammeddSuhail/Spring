package spring_project_annotations_autowire;

public interface CoachInterface {
	public String getDetails(); 
}
