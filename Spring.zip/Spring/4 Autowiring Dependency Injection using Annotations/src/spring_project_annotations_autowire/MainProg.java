package spring_project_annotations_autowire;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainProg {

	public static void main(String[] args) {
		
		//load spring configuration file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
				
		
		
		//retrieve bean(class) from spring container
		//here we gave id to the bean
		//Autowiring: Constructor Injection 
		System.out.println("Using Constructor Injection");
		JumppingCoach coach1 = context.getBean("jumpId", JumppingCoach.class);
		System.out.println(coach1.getDetails());
		System.out.println(coach1.getBoxDetails());
		
		
		
		
		//retrieve bean(class) from spring container
		//here it is default bean name 
		//if bean name: JumppingCoach2
		//then default id: jumppingCoach2
		//Autowiring: Settter Injection
		System.out.println("\nUsing Settter Injection");
		JumppingCoach2 coach2 = context.getBean("jumppingCoach2", JumppingCoach2.class);
		System.out.println(coach2.getDetails());
		System.out.println(coach2.getBoxDetails());
		
		
		//Autowiring: Method Injection
		System.out.println("\nUsing Method Injection");
		JumppingCoach3 coach3 = context.getBean("jumppingCoach3", JumppingCoach3.class);
		System.out.println(coach3.getDetails());
		System.out.println(coach3.getBoxDetails());
		
		
		//Autowiring: Field Injection
		System.out.println("\nUsing Field Injection");
		JumppingCoach4 coach4 = context.getBean("jumppingCoach4", JumppingCoach4.class);
		System.out.println(coach4.getDetails());
		System.out.println(coach4.getBoxDetails());
		
		
		
		
		//Autowiring: @Qualifier with Field Injection 
		System.out.println("\nUses Qualifier Annotation to be specify which bean to use when mutiple implementaton of interface is there");
		JumppingCoach5UsesQualifierAnnotation coach5 = context.getBean("jumppingCoach5UsesQualifierAnnotation", JumppingCoach5UsesQualifierAnnotation.class);
		System.out.println(coach5.getDetails());
		System.out.println(coach5.getBoxDetails());
		
		
		//close the context
		context.close();

	}

}
