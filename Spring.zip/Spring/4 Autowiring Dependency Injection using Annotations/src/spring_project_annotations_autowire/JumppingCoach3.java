package spring_project_annotations_autowire;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JumppingCoach3 implements CoachInterface {
	
	BoxerInterface boxerInterface;
	
	//For Method injection:
	//any method can be used for dependency injection
	//the @Autowired will basically search for bean and create it
	@Autowired
	public void findTheBean(BoxerInterface boxerInterface) {
		this.boxerInterface = boxerInterface;
	}

	@Override
	public String getDetails() {
		return "coach2: Jump harder";
	}
	
	public BoxerInterface getBoxerInterface() {
		return boxerInterface;
	}
	
	public String getBoxDetails() {
		return boxerInterface.boxingDetails();
	}

}
