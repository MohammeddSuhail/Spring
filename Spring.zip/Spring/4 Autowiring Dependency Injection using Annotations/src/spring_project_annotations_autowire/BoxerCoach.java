package spring_project_annotations_autowire;

import org.springframework.stereotype.Component;

@Component
public class BoxerCoach implements BoxerInterface{

	@Override
	public String boxingDetails() {
		return "Wake up and box for 1 hour each day";
	}

}
